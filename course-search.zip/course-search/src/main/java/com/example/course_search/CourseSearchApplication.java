package com.example.course_search;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseSearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourseSearchApplication.class, args);
	}

}
