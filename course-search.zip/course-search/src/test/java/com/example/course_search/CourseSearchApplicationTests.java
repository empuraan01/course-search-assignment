package com.example.course_search;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
